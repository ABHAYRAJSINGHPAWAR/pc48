package com.exception;

@SuppressWarnings("serial")
public class CustomerManagementException extends Exception {
          public CustomerManagementException (String msg) {
        	  super(msg);
          }
}
