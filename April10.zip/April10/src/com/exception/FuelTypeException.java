package com.exception;

@SuppressWarnings("serial")
public class FuelTypeException extends Exception{
      public FuelTypeException(String msg)
      {
    	  super(msg);
      }
}




