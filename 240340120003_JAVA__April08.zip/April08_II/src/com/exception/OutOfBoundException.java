package com.exception;

public class OutOfBoundException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public OutOfBoundException(String msg) {
		super(msg);
	}

}
