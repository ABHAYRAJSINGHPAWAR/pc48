package com.exception;

@SuppressWarnings("serial")
public class LicenseException extends Exception{
	public LicenseException(String msg) {
		super(msg);
	}

}
