package com.exception;

@SuppressWarnings("serial")
public class SpeedingException extends Exception{
       public SpeedingException(String msg) {
    	   super(msg);
       }
}
